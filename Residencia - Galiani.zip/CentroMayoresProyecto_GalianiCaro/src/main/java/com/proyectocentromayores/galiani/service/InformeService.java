package com.proyectocentromayores.galiani.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyectocentromayores.galiani.model.Informe;
import com.proyectocentromayores.galiani.repository.InformeRepository;

@Service
public class InformeService {

	@Autowired
	InformeRepository infoRepo;

	public List<Informe> findAll() {
		return infoRepo.findAll();
	}

	public Informe nuevoInforme(Informe informe) {
		return infoRepo.save(informe);
	}

	public void borrarInforme(Long idInforme) {
		infoRepo.delete(idInforme);
	}

	public void editarInforme(Informe informe) {
		infoRepo.save(informe);
	}
}
