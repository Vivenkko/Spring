package com.proyectocentromayores.galiani.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyectocentromayores.galiani.model.Apartado;
import com.proyectocentromayores.galiani.repository.ApartadoRepository;

@Service
public class ApartadoService {

	@Autowired
	ApartadoRepository repo;

	public List<Apartado> findAll() {
		return repo.findAll();
	}

	public Apartado añadirApartado(Apartado apartado) {
		return repo.save(apartado);
	}

	public void borrarApartado(Long idApartado) {
		repo.delete(idApartado);
	}

	public void editarApartado(Apartado apartado) {
		repo.save(apartado);
	}
}
