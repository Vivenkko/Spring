package com.proyectocentromayores.galiani.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.proyectocentromayores.galiani.model.Residente;

@Repository
public interface ResidenteRepository extends JpaRepository<Residente, Long>{

	List<Residente> findByNombreContainingIgnoreCase(String nombre);
}
