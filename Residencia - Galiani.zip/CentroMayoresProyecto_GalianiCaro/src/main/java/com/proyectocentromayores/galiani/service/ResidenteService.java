package com.proyectocentromayores.galiani.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyectocentromayores.galiani.model.Residente;
import com.proyectocentromayores.galiani.repository.ResidenteRepository;

@Service
public class ResidenteService {

	@Autowired
	ResidenteRepository resRepo;
	
	public List<Residente> findAll(){
		return resRepo.findAll();
	}
	
	public Residente altaResidente(Residente residente){
		return resRepo.save(residente);
	}
	
	public void borrarResidente(Long idResidente){
		 resRepo.delete(idResidente);
	}
	
	public List<Residente> findByNombre(String nombre){
		return resRepo.findByNombreContainingIgnoreCase(nombre);
	}
	
	public Residente editarResidente(Residente residente){
		return resRepo.save(residente);
	}

	public Residente finById(Long idResidente) {
		return resRepo.findOne(idResidente);
	}
}
