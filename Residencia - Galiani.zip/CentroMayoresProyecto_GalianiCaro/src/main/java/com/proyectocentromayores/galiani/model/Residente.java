package com.proyectocentromayores.galiani.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Residente {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long idResidente;
	private String nombre;
	private String apellidos;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fechaNac;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fechaIngreso;
	@OneToMany
	private List<Informe> listaInformes;
	
	//Constructores
	
	public Residente() {
		
	}

	public Residente(String nombre, String apellidos) {
		this.nombre = nombre;
		this.apellidos = apellidos;
	}
	
	public Residente(String nombre, String apellidos, Date fechaNac, Date fechaIngreso) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fechaNac = fechaNac;
		this.fechaIngreso = fechaIngreso;
	}
	
	public Residente(Long idResidente, String nombre, String apellidos, Date fechaNac, Date fechaIngreso) {
		this.idResidente = idResidente;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fechaNac = fechaNac;
		this.fechaIngreso = fechaIngreso;
	}
	
	public Residente(Long idResidente, String nombre, String apellidos, Date fechaNac, Date fechaIngreso,
			List<Informe> listaInformes) {
		this.idResidente = idResidente;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fechaNac = fechaNac;
		this.fechaIngreso = fechaIngreso;
		this.listaInformes = listaInformes;
	}

	//Getters and Setters
	
	public Long getIdResidente() {
		return idResidente;
	}

	public void setIdResidente(Long idResidente) {
		this.idResidente = idResidente;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public Date getFechaNac() {
		return fechaNac;
	}

	public void setFechaNac(Date fechaNac) {
		this.fechaNac = fechaNac;
	}

	public Date getFechaIngreso() {
		return fechaIngreso;
	}

	public void setFechaIngreso(Date fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}

	public List<Informe> getListaInformes() {
		return listaInformes;
	}

	public void setListaInformes(List<Informe> listaInformes) {
		this.listaInformes = listaInformes;
	}

	//ToString
	
	@Override
	public String toString() {
		return "Residente [idResidente=" + idResidente + ", nombre=" + nombre + ", apellidos=" + apellidos
				+ ", fechaNac=" + fechaNac + ", fechaIngreso=" + fechaIngreso + ", listaInformes=" + listaInformes
				+ "]";
	}
}
