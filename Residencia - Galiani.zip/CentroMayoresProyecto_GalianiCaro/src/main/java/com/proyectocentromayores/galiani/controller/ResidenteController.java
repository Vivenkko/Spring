package com.proyectocentromayores.galiani.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.proyectocentromayores.galiani.model.Residente;
import com.proyectocentromayores.galiani.service.ResidenteService;

@Controller
public class ResidenteController {

	@Autowired
	ResidenteService service;
	
	@GetMapping("/listado")
	public String residentes(Model model) {
		model.addAttribute("residente", service.findAll());
		return "Plantillalistado";
	}
	
	@GetMapping("/nuevoResidente")
	public String nuevoResidente (@ModelAttribute("ResidenteForm") Residente residente, Model model){
		model.addAttribute("ResidenteForm", residente);
		return "CrearResidente";
	}
	
	
	@PostMapping("/addResidente")
	public String anyadir(@ModelAttribute("ResidenteForm") Residente residente, Model model){
		model.addAttribute("ResidenteForm", residente);
		service.altaResidente(residente);
		return "redirect:/listado";
	}
	
	@GetMapping("/borrarResidente/{idResidente}")
	public String borrar(@PathVariable("idResidente")Long idResidente){
		service.borrarResidente(idResidente);
		return "redirect:/listado";
	}
	
	@GetMapping("/edit/{idResidente}")
	private String editar (@PathVariable("idResidente")Long idResidente,Model model) {
		Residente res = service.finById(idResidente);
		model.addAttribute("editarResidenteForm", res);
		return "EditarResidente";
	}
		
	@PostMapping("/{idResidente}/editado")
	public String editado(@ModelAttribute("editarResidenteForm") Residente res, Model model){	
		service.editarResidente(res);
		return "redirect:/listado";
	}
	
	@GetMapping("/informe/{idResidente}")
	public String informes(@PathVariable("idResidente")Long idResidente, Model model){
		model.addAttribute("residente", service.finById(idResidente));
		return "PlantillaInformes";
	}
}
