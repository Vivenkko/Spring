package com.proyectocentromayores.galiani.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.proyectocentromayores.galiani.model.Apartado;
import com.proyectocentromayores.galiani.model.Informe;
import com.proyectocentromayores.galiani.service.ApartadoService;
import com.proyectocentromayores.galiani.service.InformeService;
import com.proyectocentromayores.galiani.service.ResidenteService;

@Controller
public class InformeController {

	
	@Autowired
	InformeService infoService;
	
	@Autowired
	ResidenteService serviceRes;
	
	@Autowired
	ApartadoService serviceApartado;
	
	@GetMapping("/informes")
	public String mostrarInformes(Model model) {
		
		Informe informe = new Informe();
		model.addAttribute("pacientesForm", serviceRes);
		model.addAttribute("InformeForm", informe);
		model.addAttribute("residentes", serviceRes.findAll());
		
		List<Apartado> categoria = new ArrayList<Apartado>();
		categoria.add(new Apartado("Apartado Clínico"));
		categoria.add(new Apartado("Apartado Funcional"));
		categoria.add(new Apartado("Apartado Psíquico"));
		categoria.add(new Apartado("Apartado Social"));
		categoria.add(new Apartado("Apartado Ocupacional"));
		
		informe.setCategoria(categoria);
		return "crearInforme";
	}
	
	@PostMapping("/addInforme")
	public String guardar(@ModelAttribute("InformeForm") Informe informe,
			@ModelAttribute("pacientesForm") ResidenteService serviceRes, Model model,
			BindingResult bindingResult){
		
		if (bindingResult.hasErrors()) {

			return "crearInforme";
		} else {
		model.addAttribute("InformeForm", informe);
		informe.setResidente(informe.getResidente());;
		informe.setCategoria(informe.getCategoria());
		infoService.nuevoInforme(informe);
		}
		
		return "redirect:/listado";
	}
}
