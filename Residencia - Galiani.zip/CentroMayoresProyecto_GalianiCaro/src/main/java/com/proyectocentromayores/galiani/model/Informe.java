package com.proyectocentromayores.galiani.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.springframework.format.annotation.DateTimeFormat;


@Entity
public class Informe {

	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long idInforme;
	@ManyToOne
	private Residente residente;
	@OneToMany(mappedBy="informe")
	private List<Apartado> categoria;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fecha;
	
	
	// Constructores
	
	public Informe () {
		
	}

	public Informe(Residente residente, List<Apartado> categoria, Date fecha) {
		this.residente = residente;
		this.categoria = categoria;
		this.fecha = fecha;
	}

	public Informe(Long idInforme, Residente residente, List<Apartado> categoria, Date fecha) {
		super();
		this.idInforme = idInforme;
		this.residente = residente;
		this.categoria = categoria;
		this.fecha = fecha;
	}

	//Getters and Setters
	
	public Long getIdInforme() {
		return idInforme;
	}

	public void setIdInforme(Long idInforme) {
		this.idInforme = idInforme;
	}

	public Residente getResidente() {
		return residente;
	}

	public void setResidente(Residente residente) {
		this.residente = residente;
	}

	public List<Apartado> getCategoria() {
		return categoria;
	}

	public void setCategoria(List<Apartado> categoria) {
		this.categoria = categoria;
	}

	public Date getFecha() {
		return fecha;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}


	//ToString
	
	
	@Override
	public String toString() {
		return "Informe [idInforme=" + idInforme + ", residente=" + residente + ", categoria=" + categoria + ", fecha="
				+ fecha + "]";
	}
	
	
	
}
