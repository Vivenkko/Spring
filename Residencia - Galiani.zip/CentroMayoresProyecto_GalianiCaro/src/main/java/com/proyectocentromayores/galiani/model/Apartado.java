package com.proyectocentromayores.galiani.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Apartado {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long idApartado;
	@ManyToOne
	private Informe informe;
	private String categoria;
	private String diagnostico;
	private String objetivos;
	private String tareas;

	//Constructores
	
	public Apartado() {

	}
	
	public Apartado(String categoria) {
		this.categoria = categoria;
	}

	public Apartado(Long idApartado, Informe informe, String categoria, String diagnostico, String objetivos,
			String tareas) {
		this.idApartado = idApartado;
		this.informe = informe;
		this.categoria = categoria;
		this.diagnostico = diagnostico;
		this.objetivos = objetivos;
		this.tareas = tareas;
	}

	//Getter and Setters
	
	public Long getIdApartado() {
		return idApartado;
	}

	public void setIdApartado(Long idApartado) {
		this.idApartado = idApartado;
	}

	public Informe getInforme() {
		return informe;
	}

	public void setInforme(Informe informe) {
		this.informe = informe;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getDiagnostico() {
		return diagnostico;
	}

	public void setDiagnostico(String diagnostico) {
		this.diagnostico = diagnostico;
	}

	public String getObjetivos() {
		return objetivos;
	}

	public void setObjetivos(String objetivos) {
		this.objetivos = objetivos;
	}

	public String getTareas() {
		return tareas;
	}

	public void setTareas(String tareas) {
		this.tareas = tareas;
	}

	//ToString
	
	@Override
	public String toString() {
		return "Apartado [idApartado=" + idApartado + ", informe=" + informe + ", categoria=" + categoria
				+ ", diagnostico=" + diagnostico + ", objetivos=" + objetivos + ", tareas=" + tareas + "]";
	}

}
