package com.proyectocentromayores.galiani;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.proyectocentromayores.galiani.model.Residente;
import com.proyectocentromayores.galiani.repository.ResidenteRepository;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

//	@Bean
//	public CommandLineRunner Residente(ResidenteRepository repo) {
//		return (args) -> {
//			repo.save(new Residente("Miguelito", "El Camboya"));
//			repo.save(new Residente("Jose Paco", "Tunki"));
//		};
//	}
}
