package com.salesianostriana.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.salesianostriana.model.Residente;
import com.salesianostriana.services.ResidenteService;


@Controller
public class ResidenteController {

	@Autowired
	ResidenteService residenteService;
	
	@GetMapping("/")
	public String index( Model model) {
		model.addAttribute("listado", residenteService.findAll());
		return "residentes";
	}
	
	@GetMapping("/residentes")
	public String residentes( Model model) {
		model.addAttribute("listado", residenteService.findAll());
		return "residentes";
	}
	
	@GetMapping("/addResidente")
	public String insertarResidente(Model model) {
		model.addAttribute("residenteForm", new Residente());
		return "addResidente";
	}
	
	@PostMapping("/addResidente2")
	public String saveInsertarResidente(@ModelAttribute("residenteForm") Residente residente, Model model ){
		
		residenteService.addResidente(residente);
		
		return "redirect:/residentes";
	}
	
	@GetMapping("/editResidente/{id}")
	public String editarResidente( @PathVariable("id") Long id,
			Model model) {
		Residente residente = residenteService.findById(id);
		model.addAttribute("residenteForm", residente);
		return "editResidente";
	}
	
	@PostMapping("/editResidente2")
	public String saveEditarResidente(@ModelAttribute("residenteForm") Residente residente, Model model ){
		
		residenteService.addResidente(residente);
		
		return "redirect:/residentes";
	}
	
	@GetMapping("/deleteResidente/{id}")
	public String borrarResidente( @PathVariable("id") Long id) {
		residenteService.deleteResidente(id);
		return "redirect://residentes";
	}
	
}
