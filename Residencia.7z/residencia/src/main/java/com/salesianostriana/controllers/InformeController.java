package com.salesianostriana.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.salesianostriana.model.Apartado;
import com.salesianostriana.model.Informe;
import com.salesianostriana.model.Residente;
import com.salesianostriana.services.ApartadoService;
import com.salesianostriana.services.InformeService;
import com.salesianostriana.services.ResidenteService;

@Controller
public class InformeController {

	@Autowired
	InformeService informeService;
	
	@Autowired
	ResidenteService residenteService;
	
	@Autowired
	ApartadoService apartadoService;
	
	@GetMapping("/informes")
	public String index( Model model) {
		model.addAttribute("listado", informeService.findAll());
		return "informes";
	}
	
	@GetMapping("/addInforme")
	public String insertarInforme(Model model) {
		model.addAttribute("informeForm", new Informe());
		return "addInforme";
	}
	
	@PostMapping("/addInforme2")
    public String submitAddInforme(@Valid @ModelAttribute("informeForm") Informe informe, BindingResult bindingResult,
            Model model) {

        informeService.addInforme(informe);

        Residente residente = residenteService.findById(informe.getResidente().getId());
        residente.addInforme(informe);
        residenteService.addResidente(residente);

        List<Apartado> listaApartados = informe.getListaApartados();
        informeService.addInforme(informe);
        return "redirect:/informes";
    }
	
	@GetMapping("/editInforme/{id}")
	public String editarInforme( @PathVariable("id") Long id, Model model) {
		Informe informe = informeService.findById(id);
		model.addAttribute("informeForm", informe);
		return "editInforme";
	}
	
	@GetMapping("/showInforme/{id}")
	public String mostrarInforme( @PathVariable("id") Long id, Model model) {
		Informe informe = informeService.findById(id);
		if (informe != null){
			model.addAttribute("informe", informe);
			return "showInforme";
		} else{
			return "redirect:/informes";
		}
	}
	
}
