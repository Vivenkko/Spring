package com.salesianostriana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResidenciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResidenciaApplication.class, args);
	}
}
