package com.salesianostriana.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Residente {
	//Atributos
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String nombre;
    private String apellidos;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date fechaNacimiento;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date fechaIngreso;

    @OneToMany(mappedBy = "residente", cascade = CascadeType.ALL)
    private List<Informe> listaInformes = new ArrayList<>();

    //Metodos Helper
    public void addInforme(Informe informe) {
        listaInformes.add(informe);
        informe.setResidente(this);
    }

    public void removeApartado (Informe informe) {
        listaInformes.remove(informe);
        informe.setResidente(null);
    }
    
	//Constructores
	public Residente() {
		
	}
	
	public Residente(String nombre, String apellidos, Date fechaNacimiento, Date fechaIngreso) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fechaNacimiento = fechaNacimiento;
		this.fechaIngreso = fechaIngreso;
	}

	//Getters y setters
	public long getId() {
		return id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public Date getFechaIngreso() {
		return fechaIngreso;
	}

	public void setFechaIngreso(Date fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}

	public List<Informe> getListaInformes() {
		return listaInformes;
	}

	public void setListaInformes(List<Informe> listaInformes) {
		this.listaInformes = listaInformes;
	}

	public void setId(long id) {
		this.id = id;
	}

	
}
