package com.salesianostriana.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Apartado {
	//Atributos
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String tipo;
	private String diagnostico;
	private String objetivos;
	private String tareas;

    @ManyToOne
    private Informe informe;
	
	
	//Constructores
	public Apartado() {
		
	}

	public Apartado(String tipo, String diagnostico, String objetivos, String tareas) {
		this.tipo = tipo;
		this.diagnostico = diagnostico;
		this.objetivos = objetivos;
		this.tareas = tareas;
	}

	
	//Getters y setters
	public long getId() {
		return id;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDiagnostico() {
		return diagnostico;
	}

	public void setDiagnostico(String diagnostico) {
		this.diagnostico = diagnostico;
	}

	public String getObjetivos() {
		return objetivos;
	}

	public void setObjetivos(String objetivos) {
		this.objetivos = objetivos;
	}

	public String getTareas() {
		return tareas;
	}

	public void setTareas(String tareas) {
		this.tareas = tareas;
	}

	public void setInforme(Informe informe2) {
		this.informe = informe2;
		
	}

	
}
