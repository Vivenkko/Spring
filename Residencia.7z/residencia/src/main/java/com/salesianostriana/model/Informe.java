package com.salesianostriana.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Informe {
	//Atributos
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	@Temporal(TemporalType.DATE)
	private Date fecha;
	@ManyToOne(cascade = CascadeType.ALL)
	private Residente residente;
	public Residente getResidenteId() {
		return this.getResidenteId();
	}
	@OneToMany(mappedBy="informe", cascade = CascadeType.ALL)
	private List<Apartado> listaApartados = new ArrayList<>();
	
	//Metodos Helper
    public void addApartado(Apartado apartado) {
        listaApartados.add(apartado);
        apartado.setInforme(this);
    }

    public void removeApartado (Apartado apartado) {
        listaApartados.remove(apartado);
        apartado.setInforme(null);
    }
	
	//Constructores
	public Informe() {
		
	}

	public Informe(Date fecha, Residente residente) {
		this.fecha = fecha;
		this.residente = residente;
	}

	
	//Getters y setters
	public long getId() {
		return id;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Residente getResidente() {
		return residente;
	}

	public List<Apartado> getListaApartados() {
		return listaApartados;
	}

	public void setListaApartados(List<Apartado> listaApartados) {
		this.listaApartados = listaApartados;
	}

	public void setResidente(Residente residente) {
		this.residente = residente;
	}
	
	
}
