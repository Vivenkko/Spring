package com.salesianostriana.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianostriana.model.Apartado;


public interface ApartadoRepository extends JpaRepository<Apartado, Long> {
	
}