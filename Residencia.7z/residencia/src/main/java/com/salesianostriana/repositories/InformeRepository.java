package com.salesianostriana.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianostriana.model.Informe;

public interface InformeRepository extends JpaRepository<Informe, Long> {
	
}