package com.salesianostriana.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.salesianostriana.model.Apartado;
import com.salesianostriana.repositories.ApartadoRepository;

@Service
public class ApartadoService {
	
	@Autowired
	ApartadoRepository apartadoRepo;
	
	public List<Apartado> findAll(){
		return apartadoRepo.findAll();
	}
	
	public Apartado findById(Long id) {
		return apartadoRepo.findOne(id);
	}
	
	public Apartado addApartado(Apartado apartado) {
		return apartadoRepo.save(apartado);
	}
	
	public void deleteApartado(Apartado apartado) {
		apartadoRepo.delete(apartado);
	}
	
}
