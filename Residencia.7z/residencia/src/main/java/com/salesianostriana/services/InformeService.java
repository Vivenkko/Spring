package com.salesianostriana.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.salesianostriana.model.Informe;
import com.salesianostriana.repositories.InformeRepository;

@Service
public class InformeService {

	@Autowired
	InformeRepository informeRepo;
	
	public List<Informe> findAll(){
		return informeRepo.findAll();
	}
	
	public Informe findById(Long id) {
		return informeRepo.findOne(id);
	}
	
	public Informe addInforme(Informe informe) {
		return informeRepo.save(informe);
	}
	
	public void deleteInforme(Informe informe) {
		informeRepo.delete(informe);
	}
	
}
