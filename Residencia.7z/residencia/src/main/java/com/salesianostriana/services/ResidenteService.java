package com.salesianostriana.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.salesianostriana.model.Residente;
import com.salesianostriana.repositories.ResidenteRepository;

@Service
public class ResidenteService {

	@Autowired
	ResidenteRepository residenteRepo;
	
	public List<Residente> findAll(){
		return residenteRepo.findAll();
	}
	
	public Residente findById(Long id) {
		return residenteRepo.findOne(id);
	}
	
	public Residente addResidente(Residente residente) {
		return residenteRepo.save(residente);
	}
	
	public void deleteResidente(Long id) {
		residenteRepo.delete(id);
	}
	
}
