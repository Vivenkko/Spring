package spring;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import spring.model.Direccion;
import spring.model.Persona;
import spring.repository.PersonaRepository;

@SpringBootApplication
public class ResApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResApplication.class, args);
	}
	
	@Bean
	public CommandLineRunner demo(PersonaRepository repository) {
		return (args) -> {
			repository.save(new Persona("Javier", "Lagares",
					new Direccion("Mandoble, 8", "41400", "Ecija", "Sevilla")));
			repository.save(new Persona("Miguel", "Morales",
					new Direccion("Mandoble, 8", "41400", "Malaga", "Sevilla")));
			repository.save(new Persona("Manuel", "Gomez",
					new Direccion("Mandoble, 8", "41400", "Sevilla", "Sevilla")));
			repository.save(new Persona("Jose", "Martin",
					new Direccion("Mandoble, 8", "41400", "Huelva", "Sevilla")));
			repository.save(new Persona("Miguel", "Morales",
					new Direccion("Mandoble, 8", "41400", "Granada", "Sevilla")));
			repository.save(new Persona("Pedro", "Blanco",
					new Direccion("Mandoble, 8", "41400", "Utrera", "Sevilla")));
			repository.save(new Persona("Maria", "Lagares",
					new Direccion("Mandoble, 8", "41400", "Écija", "Sevilla")));
			repository.save(new Persona("Manuel", "Martin",
					new Direccion("Mandoble, 8", "41400", "Écija", "Sevilla")));
			repository.save(new Persona("Maria", "Gomez",
					new Direccion("Mandoble, 8", "41400", "Écija", "Sevilla")));
			repository.save(new Persona("Javier", "Gomez",
					new Direccion("Mandoble, 8", "41400", "Écija", "Sevilla")));
			repository.save(new Persona("Jose", "Blanco",
					new Direccion("Mandoble, 8", "41400", "Écija", "Sevilla")));
			repository.save(new Persona("Bruce", "Black",
					new Direccion("Mandoble, 8", "41400", "Écija", "Sevilla")));
			repository.save(new Persona("Juan", "Blanco",
					new Direccion("Mandoble, 8", "41400", "Écija", "Sevilla")));
			repository.save(new Persona("Juan", "Gomez",
					new Direccion("Mandoble, 8", "41400", "Écija", "Sevilla")));
			repository.save(new Persona("Manuel", "Lagares",
					new Direccion("Mandoble, 8", "41400", "Écija", "Sevilla")));
		};
	}
}
