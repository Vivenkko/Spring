package spring.model;

import javax.persistence.Embeddable;

@Embeddable
public class Direccion {
	
	private String nombreynum;
	private String cp;
	private String poblacion;
	private String provincia;
	
	public Direccion() {
	}
	
	public Direccion(String nombreynum, String cp, String poblacion, String provincia) {
		this.nombreynum = nombreynum;
		this.cp = cp;
		this.poblacion = poblacion;
		this.provincia = provincia;
	}

	public String getNombreynum() {
		return nombreynum;
	}

	public void setNombreynum(String nombreynum) {
		this.nombreynum = nombreynum;
	}

	public String getCp() {
		return cp;
	}

	public void setCp(String cp) {
		this.cp = cp;
	}

	public String getPoblacion() {
		return poblacion;
	}

	public void setPoblacion(String poblacion) {
		this.poblacion = poblacion;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	@Override
	public String toString() {
		return "Direccion [nombreynum=" + nombreynum + ", cp=" + cp + ", poblacion=" + poblacion
				+ ", provincia=" + provincia + "]";
	}
	
}
