package spring.controladores;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import spring.exception.PersonaSinDatosException;
import spring.model.Persona;
import spring.services.PersonaService;

@RestController
public class WelcomeController {

	@Autowired
	PersonaService personaService;
	
	@GetMapping("/personas")
	public List<Persona> listarPersonas() {
		return personaService.findAll();
	}
	
	@GetMapping("/personas/{id}")
	public Persona obtenerPersona(@PathVariable("id") long id) {
		return personaService.findOne(id);
	}
	
	@GetMapping("/personasPorNombre/{nombre}")
	public List<Persona> buscarPorNombre(@PathVariable("nombre") String nombre) {
		return personaService.findByNombre(nombre);
	}
	
	@GetMapping("/personasPorApellidos/{apellidos}")
	public List<Persona> buscarPorApellidos(@PathVariable("apellidos") String apellidos) {
		return personaService.findByApellidos(apellidos);
	}
	
	@GetMapping("/personasPorNombreYApellidos/{nombre}/{apellidos}")
	public List<Persona> buscarPorNombreYApellidos(@PathVariable("nombre") String nombre, 
			@PathVariable("apellidos") String apellidos) {
		return personaService.findByNombreAndApellidos(nombre, apellidos);
	}
	
	@PostMapping("/persona")
	public ResponseEntity<?> crearPersona(@RequestBody Persona persona, HttpServletResponse response) {
		if(persona.getNombre() != null && persona.getApellidos() != null) {
			Persona p = personaService.save(persona);
			return new ResponseEntity<Persona>(p, HttpStatus.CREATED);
		} else {
			throw new PersonaSinDatosException();
		}
		
	}
	
	@PutMapping("/persona")
	public Persona editarPersona(@RequestBody Persona persona) {
		if(personaService.findOne(persona.getId()) != null) {
			return personaService.edit(persona);
		} 
		return null;
	}
	
	@DeleteMapping("/persona")
	public Persona eliminarPersona(@RequestBody Persona persona) {
		Persona p = personaService.findOne(persona.getId());
		personaService.deletePersona(p);
		return null;
	}
	
}
