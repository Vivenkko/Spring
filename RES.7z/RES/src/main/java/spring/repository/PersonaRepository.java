package spring.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import spring.model.Persona;


public interface PersonaRepository extends JpaRepository<Persona, Long> {

	public List<Persona> findByNombreIgnoreCase(String nombre);
	
	public List<Persona> findByApellidosIgnoreCase(String apellidos);
	
	public List<Persona> findByNombreAndApellidosAllIgnoreCase(String nombre, String apellidos);
	
}
