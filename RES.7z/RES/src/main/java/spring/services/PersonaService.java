package spring.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.model.Persona;
import spring.repository.PersonaRepository;

@Service
public class PersonaService {
	
	@Autowired
	PersonaRepository personaRepo;
	
	public List<Persona> findAll() {
		return personaRepo.findAll();
	}
	
	public Persona findOne(long id) {
		return personaRepo.findOne(id);
	}
	
	public Persona save(Persona persona) {
		return personaRepo.save(persona);
	}
	
	public Persona edit(Persona persona) {
		return personaRepo.save(persona);
	}
	
	public Persona addPersona(Persona persona) {
		return personaRepo.save(persona);
	}
	
	public void deletePersona(Persona persona) {
		personaRepo.delete(persona);
	}
	
	public List<Persona> findByNombre(String nombre) {
		return personaRepo.findByNombreIgnoreCase(nombre);
	}
	
	public List<Persona> findByApellidos(String apellidos) {
		return personaRepo.findByApellidosIgnoreCase(apellidos);
	}
	
	public List<Persona> findByNombreAndApellidos(String nombre, String apellidos) {
		return personaRepo.findByNombreAndApellidosAllIgnoreCase(nombre, apellidos);
	}
}
